using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_test : MonoBehaviour
{
    public void btn_click()
    {
        Debug.Log("test");
    }
}
